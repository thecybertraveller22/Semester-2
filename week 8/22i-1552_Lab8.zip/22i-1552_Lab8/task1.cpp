#include"task1.h"
#include<iostream>
#include<cstdlib>

using namespace std;

IntegerList::IntegerList()
{

}

IntegerList::IntegerList(int s)
{
    this->size = s;
    numelements = 0;
    list = new int[size];

    for(int i=0;i<size;i++)
    {
        list[i] = 0;
    }
}

IntegerList::IntegerList(IntegerList &copy)
{
    this->size = copy.size;
    numelements = copy.numelements;
    list = new int[size];

    for(int i=0;i<size;i++)
    {
        list[i] = copy.list[i];
    }
}

bool IntegerList::isValid(int subscript)
{
    return subscript>=0 && subscript<numelements;
}

void IntegerList::setElement(int subscript, int value)
{
    cout<<"SET ELEMENT"<<endl;
    if(isValid(subscript))
    {
        list[subscript]=value;
    }
    else
    {
        cout<<"Subscript doesnot validate"<<endl;
        exit(EXIT_FAILURE);
    }
}

int IntegerList::getElement(int subscript)
{
    cout<<"GET ELEMENT "<<endl;
    if(isValid(subscript))
    {
        return list[subscript];
    }
    else
    {
        cout<<"Subscript doesnot validate"<<endl;
        exit(EXIT_FAILURE);
    }
}

IntegerList::~IntegerList()
{
    delete[] list;
}


int main()
{
    
    IntegerList myList(5);


    myList.setElement(0, 1);
    myList.setElement(1, 2);
    myList.setElement(2, 3);
    myList.setElement(3, 4);
    myList.setElement(0, 4);


    for(int i = 0; i < 5; i++)
    {
        cout << "Element " << i << " = " << myList.getElement(i) << endl;
    }

    
    IntegerList myCopy(myList);

   
    myList.setElement(2, 10);

   
    cout << "Original List: ";
    for(int i = 0; i < 5; i++)
    {
        cout << myList.getElement(i) << " ";
    }
    cout << endl;

    cout << "Copy of List: ";
    for(int i = 0; i < 5; i++)
    {
        cout << myCopy.getElement(i) << " ";
    }
    cout << endl;

    return 0;
}
